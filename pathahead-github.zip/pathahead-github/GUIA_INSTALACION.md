# Guía de instalación — Calculadora PathAhead

Tienes tres archivos:
- **pathahead_calculadora.html** — la calculadora (esto es lo que la gente usa).
- **apps_script.gs** — el código que guarda cada registro en tu Google Sheet.
- **esta guía**.

El objetivo: que cada vez que alguien deje su correo, aparezca una fila nueva en tu hoja de cálculo. Toma unos 15 minutos y no requiere saber programar. Sigue los pasos en orden.

---

## Paso 1 — Crea la hoja de cálculo (2 min)
1. Entra a [sheets.google.com](https://sheets.google.com) y crea una hoja nueva.
2. Ponle un nombre, por ejemplo **PathAhead — Leads**.
3. Déjala abierta. (No necesitas crear columnas; el script las crea solo la primera vez.)

## Paso 2 — Pega el script (4 min)
1. En esa misma hoja, ve al menú **Extensiones → Apps Script**.
2. Borra el código de ejemplo que aparece.
3. Abre el archivo **apps_script.gs**, copia TODO su contenido y pégalo ahí.
4. Haz clic en el ícono de **guardar** (el disquete).

## Paso 3 — Publica el script como aplicación web (4 min)
1. Arriba a la derecha, clic en **Implementar → Nueva implementación**.
2. En el ícono de engranaje (tipo), elige **Aplicación web**.
3. Configura así:
   - **Descripción:** PathAhead leads
   - **Ejecutar como:** Yo (tu correo)
   - **Quién tiene acceso:** **Cualquier usuario**
4. Clic en **Implementar**. Google te pedirá **autorizar permisos** la primera vez: acepta (te dirá que la app "no está verificada" — es normal porque es tuya; entra en *Configuración avanzada → Ir a (tu proyecto)* y permite).
5. Copia la **URL de la aplicación web** que termina en `/exec`. Esa es tu dirección.

> Para comprobar que quedó viva: pega esa URL en el navegador. Debe decir *"PathAhead endpoint activo."*

## Paso 4 — Conecta la calculadora (1 min)
1. Abre **pathahead_calculadora.html** con un editor de texto (Bloc de notas, TextEdit, o VS Code).
2. Cerca del inicio del bloque de código, busca esta línea:
   ```
   const SHEET_ENDPOINT = "PEGA_AQUI_TU_URL_DE_APPS_SCRIPT";
   ```
3. Reemplaza `PEGA_AQUI_TU_URL_DE_APPS_SCRIPT` por la URL `/exec` que copiaste (entre las comillas).
4. Guarda el archivo.

> Opcional: justo debajo verás `const SUBSTACK_URL = "PEGA_AQUI_TU_SUBSTACK";`. Si pones ahí la URL de tu Substack, aparecerá un enlace "Leer el Substack" en el formulario. Si la dejas igual, simplemente no se muestra.

Listo: ahora cada envío cae en tu hoja.

## Paso 5 — Publícala gratis en GitHub Pages (8 min)
La calculadora es un solo archivo. Para que la URL quede limpia, primero **renómbralo a `index.html`** (clic derecho → renombrar). Luego:
1. Crea una cuenta gratis en [github.com](https://github.com) si aún no tienes.
2. Arriba a la derecha, **+ → New repository**. Ponle un nombre (por ej. `calculadora`), márcalo **Public** y créalo.
3. En el repo vacío, clic en **Add file → Upload files** y **arrastra tu `index.html`**. Abajo, **Commit changes**.
4. Ve a **Settings → Pages** (menú lateral). En **Source** elige la rama **main** y carpeta **/ (root)**. Guarda.
5. Espera 1–2 minutos y recarga: GitHub te muestra tu URL, del estilo **`https://TU-USUARIO.github.io/calculadora/`**. Esa es la que compartes.

> Como GitHub Pages sirve por HTTPS, la conexión a tu Google Sheet (Paso 3) funciona sin problema.
> Para actualizar la calculadora más adelante, vuelve a subir el `index.html` (Add file → Upload → Commit) y en un par de minutos se refresca sola.

---

## Cómo la asocias a Substack y LinkedIn

Ni Substack ni LinkedIn permiten incrustar herramientas interactivas dentro de un post — así que el patrón es **enlazar**, no embeber:

- **Substack:** escribe el post con el gancho (el caso que cae en rojo / la sorpresa de Toronto), pon una imagen o un GIF corto de la calculadora en acción, y debajo un enlace: *"Ábrela tú →"* apuntando a tu URL de GitHub Pages.
- **LinkedIn:** publica el mismo gancho como texto + una captura, y pon el enlace a la calculadora en el **primer comentario** (LinkedIn da más alcance cuando el link va en comentario, no en el cuerpo).

Como la calculadora pide el correo y tu Substack vive de correos, el flujo se cierra solo: alguien llega del post → usa la calculadora → te deja su correo → lo tienes en la hoja → lo sumas a tu Substack.

## Cómo pasas los correos a tu newsletter
Cuando tengas correos en la hoja, expórtalos así: en Google Sheets, **Archivo → Descargar → CSV**, y luego en Substack usa **importar suscriptores** (admite CSV). Hazlo cada cierto tiempo, o revisa la hoja para hacer outreach 1:1 a los perfiles más interesantes (por eso pides LinkedIn opcional).

---

## Lo que recibes por cada persona (columnas de la hoja)
`fecha · email · linkedin · tipo · salida · nivel · efectivo_usd · tasa_interes · prioridad · programa_mas_barato · programa_mas_rapido · ya_estudio · programa_real · comp_real · visa_real`

`tipo`, `salida`, `nivel` y `prioridad` te dicen qué evalúa y qué valora cada persona; `programa_mas_barato`/`programa_mas_rapido` te muestran qué programa le convino. Las últimas cuatro solo se llenan cuando alguien marca *"ya estudié un máster en US"*: tu cosecha de datos verificados (qué universidad/programa, su comp real y su visa).

---

## Notas importantes
- **Los números actuales son ilustrativos.** Sirven para lanzar y validar, pero antes de presumir cifras, reemplázalos con tu data (en el código, el bloque `const DATA = {...}` tiene los salarios, costos de vida e impuestos por ciudad, fáciles de editar). Las fuentes para hacerlo: Levels.fyi, Built In, Glassdoor y la base H-1B/LCA de EE.UU.
- **Privacidad:** estás recolectando correos. Añade una línea simple de consentimiento si quieres ("Al enviar, aceptas recibir el newsletter; puedes darte de baja cuando quieras").
- Si cambias el código del script más adelante, recuerda crear una **nueva implementación** (o "Administrar implementaciones" → editar) para que los cambios tomen efecto.
