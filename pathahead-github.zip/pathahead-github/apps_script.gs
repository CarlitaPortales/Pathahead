/**
 * PathAhead — recolector de leads de la calculadora (comparación de programas reales).
 * Pega TODO esto en el editor de Apps Script de tu Google Sheet
 * (Extensiones → Apps Script), guarda y despliega como "Aplicación web".
 * Instrucciones completas en GUIA_INSTALACION.md
 */
function doPost(e) {
  try {
    var lock = LockService.getScriptLock();
    lock.waitLock(5000);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName('Leads');
    if (!sheet) {
      sheet = ss.insertSheet('Leads');
      sheet.appendRow([
        'fecha','email','linkedin','tipo','salida','nivel',
        'efectivo_usd','tasa_interes','prioridad',
        'programa_mas_barato','programa_mas_rapido',
        'ya_estudio','programa_real','comp_real','visa_real'
      ]);
    }
    var p = JSON.parse(e.postData.contents);
    sheet.appendRow([
      p.timestamp || new Date(),
      p.email || '', p.linkedin || '',
      p.tipo || '', p.salida || '', p.nivel || '',
      p.efectivo_usd || '', p.tasa_interes || '', p.prioridad || '',
      p.programa_mas_barato || '', p.programa_mas_rapido || '',
      p.moved || '', p.movedProg || '', p.movedComp || '', p.movedVisa || ''
    ]);
    lock.releaseLock();
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  }
}
function doGet() {
  return ContentService.createTextOutput('PathAhead endpoint activo.').setMimeType(ContentService.MimeType.TEXT);
}
